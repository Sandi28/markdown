from flask import Flask, request, render_template
import requests
from bs4 import BeautifulSoup

app = Flask(__name__)


@app.route('/')
def home():
  return render_template('index.html')


@app.route('/get_price', methods=['POST'])
def get_price():
  product_name = request.form['product_name']

  # Scraping Amazon
  amazon_url = f'https://www.amazon.com/s?k={product_name}&ref=nb_sb_noss_2'
  amazon_response = requests.get(amazon_url)
  amazon_soup = BeautifulSoup(amazon_response.content, 'html.parser')
  amazon_price = amazon_soup.find('span', {
    'class': 'a-price-whole'
  }).get_text()

  # Scraping Flipkart
  flipkart_url = f'https://www.flipkart.com/search?q={product_name}&otracker=search&otracker1=search&marketplace=FLIPKART&as-show=on&as=off'
  flipkart_response = requests.get(flipkart_url)
  flipkart_soup = BeautifulSoup(flipkart_response.content, 'html.parser')
  flipkart_price = flipkart_soup.find('div', {
    'class': '_30jeq3 _1_WHN1'
  }).get_text()

  lowest_price = min(float(amazon_price.replace(',', '')),
                     float(flipkart_price[1:].replace(',', '')))

  return render_template('result.html', lowest_price=lowest_price)


if __name__ == '_main_':
  app.run('0.0.0.0', debug=True)
